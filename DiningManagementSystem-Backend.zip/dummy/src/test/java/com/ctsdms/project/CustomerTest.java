package com.ctsdms.project;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ctsdms.project.Service.CustomerService;

@SpringBootTest
class CustomerTest {
	
	@Autowired
	CustomerService s;

	@Test
	void CustomerListEmptyTest() {
		assertNotEquals(0,s.FindAllCustomers().size());
		
	}
	
	@Test
	void CustomerComparisonTest() {
		assertNotEquals(s.findCustomerById(711l),s.findCustomerById(363l));
		
	}
	
	@Test
	void CustomerFoundTest() {
		assertNotNull(s.findCustomerById(711l));
	}

}
