import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FoodService } from '../food.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

interface Customer {
  name: string;
  phone_no: string;
  address: string;
  email: string;
  password: string;
}

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  name: any;
  phone_no: any;
  address: any;
  email: any;
  password:any;
  phnoPattern: RegExp = /^[789]\d{9}$/;

  constructor(private fs: FoodService, private router: Router) { }

  ngOnInit(): void {
  }

  registerUser() {
    if (this.email.endsWith('@gmail.com') && this.password.length >= 6 && this.phnoPattern.test(this.phone_no)) {
      this.fs.getCustomers().subscribe(
        (data: any) => {
          let isEmailExists = false;
          for (const user of data) {
            if (user.email === this.email) {
              isEmailExists = true;
              break;
            }
          }
          if (isEmailExists) {
            Swal.fire({
              icon: 'error',
              title: 'Email already exists',
              showConfirmButton: false,
              timer: 3000
            });
          } else {
            const body: Customer = {
              name: this.name,
              phone_no: this.phone_no,
              address: this.address,
              email: this.email,
              password: this.password
            };
            this.fs.postCustomer(body).subscribe(
              (res) => {
                this.router.navigate(['/login']);
                Swal.fire({
                  icon: 'success',
                  title: 'Registration successful',
                  text: 'Please login',
                  showConfirmButton: false,
                  timer: 3000
                });
              },
              (err) => {
                Swal.fire({
                  icon: 'error',
                  title: 'Email already exists',
                  timer: 3000
                });
              }
            );
          }
        }
      );
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Invalid email or password or phone number format',
        timer: 3000
      });
    }
  }

  submitForm(form: NgForm) {
    if (form.valid) {
      this.registerUser();
    }
  }
}
