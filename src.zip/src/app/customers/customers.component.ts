import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

interface User {
  customer_id: number;
  name: string;
  email: string;
  phone_no: string;
  address:string;
  password:string;
  
}
@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
 

export class CustomersComponent implements OnInit {

  
    users: User[] = [];
   
    constructor(private http: HttpClient) {}
   
    ngOnInit() {
      this.fetchUserDetails();
    }
   
    fetchUserDetails() {
      this.http.get('http://localhost:8080/dining/customer/getall').subscribe(
        (users:any) => {
          this.users = users;
        },
        (error) => {
          console.error('Error fetching user details:', error);
        }
      );
    }
  }
   
